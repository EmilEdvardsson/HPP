#define G 87

void print_pyramid(int pyramidSize);
