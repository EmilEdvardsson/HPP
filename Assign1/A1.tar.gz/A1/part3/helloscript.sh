echo Hej hej
echo Yo yo
echo test Test
